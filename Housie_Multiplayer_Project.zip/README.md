# Housie Multiplayer

Starter Flutter project structure.
